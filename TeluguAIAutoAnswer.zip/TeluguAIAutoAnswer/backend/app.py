"""
Telugu AI Auto-Pickup Call Agent
Twilio (call) -> Sarvam STT (Telugu) -> Claude (brain) -> Sarvam TTS (Telugu voice) -> Twilio
"""
import os, json, base64, uuid, hashlib, time
import requests
from flask import Flask, request, Response, send_from_directory, render_template_string
from twilio.twiml.voice_response import VoiceResponse
import anthropic
from dotenv import load_dotenv

load_dotenv()

BASE_URL = os.environ["BASE_URL"].rstrip("/")          # e.g. https://abcd.ngrok-free.app
SARVAM_KEY = os.environ["SARVAM_API_KEY"]
TWILIO_SID = os.environ["TWILIO_ACCOUNT_SID"]
TWILIO_TOKEN = os.environ["TWILIO_AUTH_TOKEN"]
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "change-me")
CLAUDE_MODEL = os.environ.get("CLAUDE_MODEL", "claude-haiku-5-5")

# Sarvam voices (check docs.sarvam.ai if names change)
VOICES = {"girl": "anushka", "boy": "abhilash"}

AUDIO_DIR = os.path.join(os.path.dirname(__file__), "static_audio")
SETTINGS_FILE = os.path.join(os.path.dirname(__file__), "settings.json")
LOG_FILE = os.path.join(os.path.dirname(__file__), "parent_messages.log")
os.makedirs(AUDIO_DIR, exist_ok=True)

app = Flask(__name__)
claude = anthropic.Anthropic()          # uses ANTHROPIC_API_KEY
CALLS = {}                              # CallSid -> {"history": [], "empty": 0}
MAX_TURNS = 6

# ---------- fixed Telugu phrases ----------
RETRY = "క్షమించండి, నాకు సరిగా వినపడలేదు. దయచేసి మళ్ళీ చెప్పండి."
BYE = "సరే, ఈ విషయం వారికి తెలియజేస్తాను. ధన్యవాదాలు, నమస్కారం."
ERR = "క్షమించండి, ఇప్పుడు సమస్య వచ్చింది. దయచేసి కొద్దిసేపటి తర్వాత మళ్ళీ ఫోన్ చేయండి."


# ---------- settings ----------
def load_settings():
    default = {
        "name": "అబ్బాయి",
        "message": "ఇప్పుడు క్లాసులో ఉన్నారు, సాయంత్రం ఆరు గంటలకు ఫోన్ చేస్తారు.",
        "voice": "girl",
    }
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            default.update(json.load(f))
    return default


def save_settings(s):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=2)


# ---------- Sarvam STT / TTS ----------
def stt(recording_url):
    audio = requests.get(recording_url + ".wav", auth=(TWILIO_SID, TWILIO_TOKEN), timeout=20).content
    r = requests.post(
        "https://api.sarvam.ai/speech-to-text",
        headers={"api-subscription-key": SARVAM_KEY},
        files={"file": ("audio.wav", audio, "audio/wav")},
        data={"model": "saarika:v2.5", "language_code": "te-IN"},
        timeout=30,
    )
    r.raise_for_status()
    return (r.json().get("transcript") or "").strip()


def tts(text, voice):
    """Returns public URL of generated Telugu speech (cached by text+voice)."""
    key = hashlib.md5(f"{voice}:{text}".encode()).hexdigest()
    path = os.path.join(AUDIO_DIR, key + ".wav")
    if not os.path.exists(path):
        r = requests.post(
            "https://api.sarvam.ai/text-to-speech",
            headers={"api-subscription-key": SARVAM_KEY, "Content-Type": "application/json"},
            json={
                "text": text[:1500],
                "target_language_code": "te-IN",
                "speaker": VOICES.get(voice, "anushka"),
                "model": "bulbul:v2",
                "speech_sample_rate": 8000,   # phone quality, faster
            },
            timeout=30,
        )
        r.raise_for_status()
        with open(path, "wb") as f:
            f.write(base64.b64decode(r.json()["audios"][0]))
    return f"{BASE_URL}/audio/{key}.wav"


# ---------- Claude brain ----------
def system_prompt(s):
    return f"""You are the Telugu-English mixed-language AI call assistant for {s['name']}. The person is unavailable to answer the call.
Speaking style:
- Speak naturally in conversational Telugu mixed with common English words, written in Telugu script where natural and English words where useful (example: "Hello, నేను {s['name']} గారి AI assistant ని. వారు ప్రస్తుతం call lift చేయలేకపోతున్నారు.").
- Keep each reply to 1-2 short sentences suitable for a phone call.
- Never hide that you are an AI assistant and never pretend to be {s['name']}.
- The only confirmed message you may share is: "{s['message']}". Do not invent extra facts or promise a time unless it appears in that message.
- If the caller shares a message, say you will pass it on to {s['name']}.
- If the caller mentions a medical emergency, accident, or urgent money issue, say you will alert {s['name']} immediately and ask them to contact {s['name']} directly if possible.
- End politely when the caller says goodbye."""


def ask_claude(s, history):
    resp = claude.messages.create(
        model=CLAUDE_MODEL,
        max_tokens=200,
        system=system_prompt(s),
        messages=history,
    )
    return resp.content[0].text.strip()


# ---------- Twilio webhooks ----------
def listen(vr):
    vr.record(action=f"{BASE_URL}/respond", method="POST", max_length=20,
              timeout=3, play_beep=False, trim="trim-silence")


@app.post("/incoming")
def incoming():
    s = load_settings()
    sid = request.form.get("CallSid", str(uuid.uuid4()))
    CALLS[sid] = {"history": [], "empty": 0}
    greeting = (
        f"నమస్కారం! నేను {s['name']} గారి ఏఐ అసిస్టెంట్‌ని. "
        f"{s['name']} గారు ప్రస్తుతం ఫోన్ తీయలేకపోతున్నారు. "
        f"వారు చెప్పమన్నది: {s['message']} "
        f"మీరు ఏమైనా చెప్పాలంటే ఇప్పుడు చెప్పండి, నేను వారికి తెలియజేస్తాను."
    )
    vr = VoiceResponse()
    try:
        vr.play(tts(greeting, s["voice"]))
        listen(vr)
    except Exception as e:
        print("incoming error:", e)
        vr.say("Sorry, please call again later.")
    return Response(str(vr), mimetype="text/xml")


@app.post("/respond")
def respond():
    s = load_settings()
    sid = request.form.get("CallSid", "")
    call = CALLS.setdefault(sid, {"history": [], "empty": 0})
    vr = VoiceResponse()
    try:
        text = ""
        if request.form.get("RecordingUrl"):
            text = stt(request.form["RecordingUrl"])

        if not text:
            call["empty"] += 1
            if call["empty"] >= 2:
                vr.play(tts(BYE, s["voice"]))
                vr.hangup()
                return Response(str(vr), mimetype="text/xml")
            reply = RETRY
        else:
            call["empty"] = 0
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%Y-%m-%d %H:%M')} | {request.form.get('From','')} | {text}\n")
            call["history"].append({"role": "user", "content": text})
            reply = ask_claude(s, call["history"])
            call["history"].append({"role": "assistant", "content": reply})

        vr.play(tts(reply, s["voice"]))
        if len(call["history"]) >= MAX_TURNS * 2:
            vr.play(tts(BYE, s["voice"]))
            vr.hangup()
        else:
            listen(vr)
    except Exception as e:
        print("respond error:", e)
        try:
            vr.play(tts(ERR, s["voice"]))
        except Exception:
            pass
        vr.hangup()
    return Response(str(vr), mimetype="text/xml")


@app.get("/audio/<name>")
def audio(name):
    return send_from_directory(AUDIO_DIR, name, mimetype="audio/wav")


# ---------- Admin page: you set the message & voice ----------
PAGE = """
<!doctype html><meta name=viewport content="width=device-width,initial-scale=1">
<title>AI Call Agent</title>
<body style="font-family:sans-serif;max-width:520px;margin:20px auto;padding:0 12px">
<h2>📞 Telugu AI Call Agent</h2>
{% if msg %}<p style="color:green">{{msg}}</p>{% endif %}
<form method=post>
  <label>Mee peru (Telugu lo)</label><br>
  <input name=name value="{{s.name}}" style="width:100%;padding:8px"><br><br>
  <label>Parents ki cheppali (Telugu lo)</label><br>
  <textarea name=message rows=4 style="width:100%;padding:8px">{{s.message}}</textarea><br><br>
  <label>Voice</label><br>
  <select name=voice style="padding:8px">
    <option value=girl {{'selected' if s.voice=='girl'}}>Girl</option>
    <option value=boy {{'selected' if s.voice=='boy'}}>Boy</option>
  </select><br><br>
  <label>Password</label><br>
  <input name=password type=password style="padding:8px"><br><br>
  <button style="padding:10px 20px">Save</button>
</form>
<h3>Parents cheppina messages</h3>
<pre style="white-space:pre-wrap">{{log}}</pre>
</body>
"""


@app.route("/", methods=["GET", "POST"])
def admin():
    msg = ""
    s = load_settings()
    if request.method == "POST":
        if request.form.get("password") == ADMIN_PASSWORD:
            s = {"name": request.form["name"], "message": request.form["message"],
                 "voice": request.form["voice"]}
            save_settings(s)
            msg = "Saved ✅"
        else:
            msg = "Wrong password"
    log = ""
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, encoding="utf-8") as f:
            log = "".join(f.readlines()[-20:])
    return render_template_string(PAGE, s=s, msg=msg, log=log)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
