# Telugu-English AI Auto-Answer Starter

This is a starter project, not a production-ready dialer. It contains:
- Android/Kotlin starter app with an auto-answer toggle and delay for SIM calls.
- A minimal `InCallService` that answers a ringing call when enabled.
- A simple `ACTION_DIAL` activity required for a default-dialer role request.
- Your Flask/Twilio/Sarvam/Claude backend, with the assistant prompt changed to conversational Telugu mixed with English words.

## Important limitation
Android normally does not allow third-party apps to capture both sides of a cellular/SIM call. The Android component can answer calls when it is the selected default phone app, but it does not connect the SIM call's audio to the AI. Do not assume it can hear or speak to the caller using AI on your Realme P3 5G. Device/OEM/Android-version behavior must be tested. A fully conversational AI call is the supported path through the separate Twilio number and cloud backend.

## A. Build the Android app
1. Install Android Studio on a computer.
2. Extract this ZIP and choose **Open** in Android Studio; select this folder (`TeluguAIAutoAnswer`).
3. Allow Gradle sync. If Android Studio asks for SDK 35, install Android SDK Platform 35 and a compatible Android Gradle plugin/JDK (JDK 17 is recommended).
4. Connect your Realme P3 5G using USB debugging, or use an Android emulator. Press **Run**.
5. Open the app and tap **Set as default phone app**. Confirm the Android system dialog.
6. Turn on **Enable auto-answer for SIM calls**, set the delay, and test using a second phone. Keep emergency calling behavior unchanged; Android uses its preloaded dialer for emergency calls.
7. If the app does not answer on your device, turn the toggle off and use the system dialer. OEM power management and default-dialer requirements can affect behavior.

This is a source starter. An APK is not included because it must be built and tested with Android Studio on a compatible build environment.

## B. Deploy the Twilio AI backend
1. Create accounts/API keys with Twilio, Sarvam AI, and Anthropic.
2. Deploy the `backend` folder to a Python host that supports Flask/Gunicorn and provides a public HTTPS URL.
3. Set the environment variables shown in `backend/.env.example` in the hosting dashboard. Do not upload `.env` or API keys to GitHub. Set `ADMIN_PASSWORD` to a strong unique value.
4. Ensure `BASE_URL` is your final public HTTPS base URL with no trailing slash.
5. Configure your Twilio phone number's **Voice / A call comes in** webhook to `https://YOUR-DOMAIN/incoming` using **HTTP POST**.
6. The backend uses `/incoming` for the initial greeting and `/respond` for recording/transcription/reply. It serves generated audio from `/audio/<filename>`.
7. Open `https://YOUR-DOMAIN/` to set the assistant name and message. Use the admin password.
8. Call the Twilio number from a separate phone. Test with non-sensitive messages first.

## C. Telugu + English mixed speech
The backend prompt asks Claude to reply in conversational Telugu with common English words. The current STT request is configured for `te-IN`; mixed-language recognition quality must be tested. If English words are misrecognized, evaluate the current Sarvam API's supported language/code-switch options and adjust based on its current documentation.

## Security and reliability checklist before real use
- Add Twilio webhook signature validation before exposing the service publicly.
- Protect the admin page with a strong password and HTTPS; add rate limiting.
- Set appropriate data retention and consent notices for recordings/transcripts.
- Add persistent call state (the current `CALLS` dictionary is memory-only and can be lost on restart).
- Verify current Claude model ID and Sarvam API request schemas against provider docs before deployment.
- Do not use this starter for emergency calls or as a guaranteed emergency response system.
