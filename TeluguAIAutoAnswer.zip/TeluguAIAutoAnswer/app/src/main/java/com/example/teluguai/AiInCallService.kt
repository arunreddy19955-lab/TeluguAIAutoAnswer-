package com.example.teluguai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.VideoProfile

/**
 * Minimal SIM call auto-answer starter.
 * This answers the cellular call; it does NOT provide AI access to the cellular call audio.
 */
class AiInCallService : InCallService() {
    private val handler = Handler(Looper.getMainLooper())
    private val pending = mutableMapOf<Call, Runnable>()

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        if (call.state != Call.STATE_RINGING) return
        val prefs = getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("auto_answer", false)) return

        val delayMs = prefs.getInt("delay_seconds", 3).coerceIn(0, 10) * 1000L
        val task = Runnable {
            if (call.state == Call.STATE_RINGING) {
                try { call.answer(VideoProfile.STATE_AUDIO_ONLY) } catch (_: SecurityException) { }
            }
            pending.remove(call)
        }
        pending[call] = task
        handler.postDelayed(task, delayMs)
        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(changedCall: Call, state: Int) {
                if (state != Call.STATE_RINGING) {
                    pending.remove(changedCall)?.let { handler.removeCallbacks(it) }
                    changedCall.unregisterCallback(this)
                }
            }
        })
    }

    override fun onCallRemoved(call: Call) {
        pending.remove(call)?.let { handler.removeCallbacks(it) }
        super.onCallRemoved(call)
    }
}
