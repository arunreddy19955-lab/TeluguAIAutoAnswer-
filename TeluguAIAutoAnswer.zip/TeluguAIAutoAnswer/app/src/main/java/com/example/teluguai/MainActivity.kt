package com.example.teluguai

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("agent_settings", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var autoAnswer: Switch
    private lateinit var delayBar: SeekBar
    private lateinit var delayLabel: TextView
    private lateinit var backendUrl: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 24)
            gravity = Gravity.TOP
        }
        fun addText(text: String, size: Float = 16f) {
            root.addView(TextView(this).apply { this.text = text; textSize = size; setPadding(0, 8, 0, 8) })
        }
        addText("Telugu-English AI Call Agent", 24f)
        addText("SIM calls: auto-answer control only. Android normally blocks third-party apps from accessing both sides of cellular-call audio.", 14f)

        status = TextView(this).apply { textSize = 15f; setPadding(0, 12, 0, 12) }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Set as default phone app"
            setOnClickListener { requestDialerRole() }
        })

        autoAnswer = Switch(this).apply {
            text = "Enable auto-answer for SIM calls"
            isChecked = prefs.getBoolean("auto_answer", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("auto_answer", checked).apply() }
            setPadding(0, 18, 0, 8)
        }
        root.addView(autoAnswer)
        delayLabel = TextView(this)
        root.addView(delayLabel)
        delayBar = SeekBar(this).apply {
            max = 10
            progress = prefs.getInt("delay_seconds", 3).coerceIn(0, 10)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    delayLabel.text = "Answer delay: $progress seconds"
                    if (fromUser) prefs.edit().putInt("delay_seconds", progress).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        delayLabel.text = "Answer delay: ${delayBar.progress} seconds"
        root.addView(delayBar)

        addText("Twilio backend URL (for reference)")
        backendUrl = EditText(this).apply {
            hint = "https://your-server.example.com"
            setSingleLine(true)
            setText(prefs.getString("backend_url", ""))
        }
        root.addView(backendUrl)
        root.addView(Button(this).apply {
            text = "Save settings"
            setOnClickListener {
                prefs.edit().putString("backend_url", backendUrl.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Settings saved", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Open Android call settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
        })
        addText("Twilio calls are handled by the Python backend, not by this SIM-call service. Configure Twilio Voice webhook to POST /incoming.", 14f)
        setContentView(ScrollView(this).apply { addView(root) })
        refreshStatus()
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) && !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER), 1001)
            } else refreshStatus()
        } else {
            startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        }
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) refreshStatus() }

    private fun refreshStatus() {
        val held = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)
        } else false
        status.text = if (held) "Default phone role: enabled" else "Default phone role: not enabled"
    }
}
