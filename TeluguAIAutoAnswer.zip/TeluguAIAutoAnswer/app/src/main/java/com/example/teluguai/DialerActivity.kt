package com.example.teluguai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Basic dial-pad entry point to satisfy the default-dialer ACTION_DIAL requirement. */
class DialerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val number = EditText(this).apply {
            hint = "Phone number"
            setSingleLine(true)
            setText(intent?.data?.schemeSpecificPart ?: "")
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            addView(TextView(this@DialerActivity).apply { text = "Telugu AI Dialer"; textSize = 22f })
            addView(number)
            addView(Button(this@DialerActivity).apply {
                text = "Call"
                setOnClickListener {
                    val digits = number.text.toString().trim()
                    if (digits.isBlank()) {
                        Toast.makeText(this@DialerActivity, "Enter a phone number", Toast.LENGTH_SHORT).show()
                    } else {
                        try {
                            val telecom = getSystemService(TelecomManager::class.java)
                            telecom.placeCall(Uri.fromParts("tel", digits, null), Bundle())
                        } catch (e: Exception) {
                            startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", digits, null)))
                        }
                    }
                }
            })
        }
        setContentView(root)
    }
}
